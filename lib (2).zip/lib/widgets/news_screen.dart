import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:html/dom.dart' as html_dom;
import 'package:html/parser.dart' as html_parser;
import 'package:http/http.dart' as http;

import 'app_bottom_navigation.dart';

// ─── Model ───────────────────────────────────────────────────────────────────

class NewsArticle {
  final String title;
  final String category;
  final String imageUrl;
  final String articleUrl;
  final String publishedAt;
  final bool isFeatured;

  const NewsArticle({
    required this.title,
    required this.category,
    required this.imageUrl,
    required this.articleUrl,
    this.publishedAt = '',
    this.isFeatured = false,
  });

  NewsArticle copyWith({String? publishedAt}) => NewsArticle(
    title: title,
    category: category,
    imageUrl: imageUrl,
    articleUrl: articleUrl,
    publishedAt: publishedAt ?? this.publishedAt,
    isFeatured: isFeatured,
  );
}

// ─── Parser ──────────────────────────────────────────────────────────────────

class _ParsedNewsPage {
  const _ParsedNewsPage({required this.articles, required this.hasNextPage});

  final List<NewsArticle> articles;
  final bool hasNextPage;
}

_ParsedNewsPage _parseNewsPage(String source, int currentPage) {
  const base = 'https://ueh.edu.vn';
  final document = html_parser.parse(source);
  final articles = <NewsArticle>[];
  var currentCategory = '';

  for (final element in document.querySelectorAll('article.card.list-item')) {
    html_dom.Element? categoryLink;
    html_dom.Element? titleLink;
    for (final link in element.querySelectorAll('h3 a[href]')) {
      final href = link.attributes['href']?.trim() ?? '';
      if (href.endsWith('/')) {
        categoryLink ??= link;
      } else {
        titleLink ??= link;
      }
    }
    if (categoryLink != null) currentCategory = categoryLink.text.trim();

    final title = titleLink?.text.trim() ?? '';
    final articlePath = titleLink?.attributes['href'] ?? '';
    if (title.isEmpty || articlePath.isEmpty) continue;

    final imagePath =
        element.querySelector('.card-photo img')?.attributes['src'] ??
        element.querySelector('img')?.attributes['src'] ??
        '';
    articles.add(
      NewsArticle(
        title: title,
        category: currentCategory,
        imageUrl: _resolveUrl(base, imagePath),
        articleUrl: _resolveUrl(base, articlePath),
        isFeatured: currentPage == 1 && articles.isEmpty,
      ),
    );
  }

  var lastPage = currentPage;
  for (final link in document.querySelectorAll('.pagination a[href]')) {
    final href = link.attributes['href'] ?? '';
    final match = RegExp(r'/page/(\d+)/?').firstMatch(href);
    final page = int.tryParse(match?.group(1) ?? '');
    if (page != null && page > lastPage) lastPage = page;
  }

  return _ParsedNewsPage(
    articles: articles,
    hasNextPage: lastPage > currentPage,
  );
}

String _resolveUrl(String base, String url) {
  if (url.startsWith('http')) return url;
  return '$base$url';
}

String _clean(String s) => s
    .replaceAll(RegExp(r'<[^>]+>'), '')
    .replaceAll('&amp;', '&')
    .replaceAll('&lt;', '<')
    .replaceAll('&gt;', '>')
    .replaceAll('&nbsp;', ' ')
    .replaceAll(RegExp(r'\s+'), ' ')
    .trim();

String _extractDate(String source) {
  final plainText = html_parser.parse(source).body?.text ?? source;
  final vietnameseDate = RegExp(
    r'\b(\d{1,2})\s+tháng\s+(\d{1,2})\s+năm\s+(\d{4})\b',
    caseSensitive: false,
  ).firstMatch(plainText);
  if (vietnameseDate != null) {
    final day = vietnameseDate.group(1)!.padLeft(2, '0');
    final month = vietnameseDate.group(2)!.padLeft(2, '0');
    return '$day/$month/${vietnameseDate.group(3)}';
  }

  final datetime = RegExp(
    r'''datetime=["'](\d{4}-\d{2}-\d{2})''',
    caseSensitive: false,
  ).firstMatch(source)?.group(1);
  final date =
      datetime ??
      RegExp(
        r'\b(\d{1,2}[/-]\d{1,2}[/-]\d{4})\b',
      ).firstMatch(_clean(source))?.group(1);
  if (date == null) return '';
  if (date.contains('-') && date.length >= 10) {
    final parts = date.substring(0, 10).split('-');
    return '${parts[2]}/${parts[1]}/${parts[0]}';
  }
  return date.replaceAll('-', '/');
}

// ─── Screen ──────────────────────────────────────────────────────────────────

class NewsScreen extends StatefulWidget {
  const NewsScreen({super.key, this.onTabSelected});

  final ValueChanged<int>? onTabSelected;

  @override
  State<NewsScreen> createState() => NewsScreenState();
}

class UehNewsPage extends StatelessWidget {
  const UehNewsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: const BackButton(),
        title: const Text('Cuộc sống UEH'),
      ),
      body: const NewsScreen(),
    );
  }
}

class NewsScreenState extends State<NewsScreen> {
  static const _uehGreen = Color(0xFF006B78);
  static const _newsUrl = 'https://ueh.edu.vn/tin-tuc';

  late Future<List<NewsArticle>> _future;
  final _scrollController = ScrollController();
  final List<NewsArticle> _additionalArticles = [];
  final Set<String> _seenArticleUrls = {};
  int _currentPage = 1;
  bool _hasMorePages = true;
  bool _isLoadingMore = false;

  @override
  void initState() {
    super.initState();
    _future = _fetchNews();
    _scrollController.addListener(_onScroll);
  }

  Future<List<NewsArticle>> _fetchNews() async {
    final page = await _fetchNewsPage(1);
    if (page.articles.isEmpty) throw Exception('Không tìm thấy bài viết nào');
    _currentPage = 1;
    _hasMorePages = page.hasNextPage;
    _seenArticleUrls
      ..clear()
      ..addAll(page.articles.map((article) => article.articleUrl));
    return _fetchPublicationDates(page.articles);
  }

  Future<_ParsedNewsPage> _fetchNewsPage(int page) async {
    final pageUrl = page == 1 ? '$_newsUrl/' : '$_newsUrl/page/$page/';
    final response = await http
        .get(Uri.parse(pageUrl))
        .timeout(const Duration(seconds: 15));
    if (response.statusCode != 200) {
      throw Exception('HTTP ${response.statusCode}');
    }
    final source = utf8.decode(response.bodyBytes, allowMalformed: true);
    return _parseNewsPage(source, page);
  }

  Future<List<NewsArticle>> _fetchPublicationDates(List<NewsArticle> articles) {
    return Future.wait(
      articles.map((article) async {
        try {
          final articleResponse = await http
              .get(Uri.parse(article.articleUrl))
              .timeout(const Duration(seconds: 15));
          if (articleResponse.statusCode != 200) return article;
          final articleHtml = utf8.decode(
            articleResponse.bodyBytes,
            allowMalformed: true,
          );
          return article.copyWith(publishedAt: _extractDate(articleHtml));
        } catch (_) {
          return article;
        }
      }),
    );
  }

  void _onScroll() {
    if (_scrollController.hasClients &&
        _scrollController.position.extentAfter < 500) {
      _loadNextPage();
    }
  }

  Future<void> _loadNextPage() async {
    if (_isLoadingMore || !_hasMorePages) return;
    setState(() => _isLoadingMore = true);

    try {
      final nextPageNumber = _currentPage + 1;
      final page = await _fetchNewsPage(nextPageNumber);
      final newArticles = page.articles
          .where((article) => _seenArticleUrls.add(article.articleUrl))
          .toList();
      final articlesWithDates = await _fetchPublicationDates(newArticles);
      if (!mounted) return;

      setState(() {
        _additionalArticles.addAll(articlesWithDates);
        _currentPage = nextPageNumber;
        _hasMorePages = page.hasNextPage && page.articles.isNotEmpty;
      });
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Không tải thêm được tin: $error')),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoadingMore = false);
    }
  }

  void reload() => setState(() {
    _additionalArticles.clear();
    _seenArticleUrls.clear();
    _currentPage = 1;
    _hasMorePages = true;
    _future = _fetchNews();
  });

  Future<void> _refresh() async {
    late Future<List<NewsArticle>> refreshed;
    setState(() {
      _additionalArticles.clear();
      _seenArticleUrls.clear();
      _currentPage = 1;
      _hasMorePages = true;
      refreshed = _fetchNews();
      _future = refreshed;
    });
    try {
      await refreshed;
    } catch (_) {
      // FutureBuilder presents the load error and retry action.
    }
  }

  @override
  void dispose() {
    _scrollController
      ..removeListener(_onScroll)
      ..dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<NewsArticle>>(
      future: _future,
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Center(
            child: CircularProgressIndicator(color: _uehGreen),
          );
        }
        if (snap.hasError) {
          return _ErrorView(message: snap.error.toString(), onRetry: reload);
        }
        return _NewsList(
          articles: [...snap.data!, ..._additionalArticles],
          hasMore: _hasMorePages,
          isLoadingMore: _isLoadingMore,
          scrollController: _scrollController,
          onTabSelected: widget.onTabSelected,
          onLoadMore: _loadNextPage,
          onRefresh: _refresh,
        );
      },
    );
  }
}

// ─── News List ───────────────────────────────────────────────────────────────

class _NewsList extends StatelessWidget {
  const _NewsList({
    required this.articles,
    required this.hasMore,
    required this.isLoadingMore,
    required this.scrollController,
    required this.onTabSelected,
    required this.onLoadMore,
    required this.onRefresh,
  });

  final List<NewsArticle> articles;
  final bool hasMore;
  final bool isLoadingMore;
  final ScrollController scrollController;
  final ValueChanged<int>? onTabSelected;
  final VoidCallback onLoadMore;
  final Future<void> Function() onRefresh;

  @override
  Widget build(BuildContext context) {
    return ScrollConfiguration(
      behavior: ScrollConfiguration.of(context).copyWith(overscroll: false),
      child: RefreshIndicator(
        color: const Color(0xFF006B78),
        onRefresh: onRefresh,
        child: CustomScrollView(
          controller: scrollController,
          physics: const AlwaysScrollableScrollPhysics(
            parent: ClampingScrollPhysics(),
          ),
          slivers: [
            // ── Header ───────────────────────────────────────────────────────
            SliverToBoxAdapter(
              child: Container(
                color: Colors.white,
                padding: const EdgeInsets.symmetric(
                  vertical: 20,
                  horizontal: 16,
                ),
                child: Column(
                  children: [
                    const Text(
                      'Tin tức',
                      style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF006B78),
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Thông tin mới nhất và kiến thức hữu ích từ UEH',
                      style: TextStyle(fontSize: 14, color: Color(0xFF999999)),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ),

            // ── Article list ─────────────────────────────────────────────────
            SliverPadding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              sliver: SliverList(
                delegate: SliverChildBuilderDelegate((context, i) {
                  final a = articles[i];
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: InkWell(
                      onTap: () => Navigator.of(context).push(
                        MaterialPageRoute<void>(
                          builder: (_) => _ArticleDetailScreen(
                            article: a,
                            onTabSelected: onTabSelected,
                          ),
                        ),
                      ),
                      child: a.isFeatured
                          ? _FeaturedCard(article: a)
                          : _RegularCard(article: a),
                    ),
                  );
                }, childCount: articles.length),
              ),
            ),

            // ── Xem thêm button ──────────────────────────────────────────────
            if (hasMore)
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                  child: OutlinedButton(
                    style: OutlinedButton.styleFrom(
                      foregroundColor: const Color(0xFF006B78),
                      side: const BorderSide(color: Color(0xFF006B78)),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: const RoundedRectangleBorder(),
                    ),
                    onPressed: isLoadingMore ? null : onLoadMore,
                    child: isLoadingMore
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Text(
                            'Xem thêm',
                            style: TextStyle(fontWeight: FontWeight.w600),
                          ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

// ─── Featured Card ────────────────────────────────────────────────────────────

class _FeaturedCard extends StatelessWidget {
  const _FeaturedCard({required this.article});

  final NewsArticle article;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.12),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        children: [
          if (article.category.isNotEmpty)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
              child: Text(
                article.category.toUpperCase(),
                style: const TextStyle(
                  color: Color(0xFF006B78),
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          AspectRatio(
            aspectRatio: 2.4,
            child: Image.network(
              article.imageUrl,
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) => Container(
                color: const Color(0xFF006B78).withValues(alpha: 0.15),
                child: const Center(
                  child: Icon(
                    Icons.image_not_supported_outlined,
                    size: 48,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ),
          Container(
            width: double.infinity,
            color: const Color(0xFF4F7182),
            padding: const EdgeInsets.fromLTRB(14, 10, 14, 16),
            child: Column(
              children: [
                const Text(
                  'TIN TỨC NỔI BẬT',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 23,
                    fontWeight: FontWeight.w800,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 12),
                Text(
                  article.title,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 17,
                    height: 1.45,
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Regular Card ─────────────────────────────────────────────────────────────

class _RegularCard extends StatelessWidget {
  const _RegularCard({required this.article});

  static const _uehGreen = Color(0xFF006B78);

  final NewsArticle article;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.07),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 17),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (article.category.isNotEmpty) ...[
              Text(
                article.category.toUpperCase(),
                style: const TextStyle(
                  color: _uehGreen,
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 7),
            ],
            Text(
              article.title,
              textAlign: TextAlign.justify,
              style: const TextStyle(
                color: Colors.black,
                fontSize: 18,
                fontWeight: FontWeight.w800,
                height: 1.28,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Error View ───────────────────────────────────────────────────────────────
Future<String> _fetchArticleHtml(NewsArticle article) async {
  final response = await http
      .get(Uri.parse(article.articleUrl))
      .timeout(const Duration(seconds: 20));
  if (response.statusCode != 200) {
    throw Exception('Không tải được bài viết (HTTP ${response.statusCode})');
  }

  final document = html_parser.parse(
    utf8.decode(response.bodyBytes, allowMalformed: true),
  );
  document
      .querySelectorAll('script, style, nav, header, footer, iframe, form')
      .forEach((element) => element.remove());

  const selectors = [
    '#news_content',
    '.news-content',
    '.article-content',
    '#short_desc',
  ];
  html_dom.Element? content;
  for (final selector in selectors) {
    final candidate = document.querySelector(selector);
    if (candidate != null && candidate.text.trim().length > 80) {
      content = candidate;
      break;
    }
  }
  if (content == null || content.innerHtml.trim().isEmpty) {
    throw Exception('Không tìm thấy phần nội dung bài viết trên UEH');
  }

  content
      .querySelectorAll(
        '#share_facebook, #share_twitter, #share_zalo, .social-share, .share-buttons',
      )
      .forEach((element) => element.remove());

  for (final element in [content, ...content.querySelectorAll('*')]) {
    element.attributes.remove('style');
    element.attributes.remove('width');
    element.attributes.remove('height');
    element.attributes.remove('align');
  }

  for (final element in content.querySelectorAll('[src], [href]')) {
    for (final attribute in ['src', 'href']) {
      final value = element.attributes[attribute];
      if (value != null && value.isNotEmpty && !value.startsWith('data:')) {
        element.attributes[attribute] = Uri.parse(
          article.articleUrl,
        ).resolve(value).toString();
      }
    }
  }
  return content.innerHtml;
}

class _ArticleDetailScreen extends StatefulWidget {
  const _ArticleDetailScreen({required this.article, this.onTabSelected});

  final NewsArticle article;
  final ValueChanged<int>? onTabSelected;

  @override
  State<_ArticleDetailScreen> createState() => _ArticleDetailScreenState();
}

class _ArticleDetailScreenState extends State<_ArticleDetailScreen> {
  late Future<String> _articleHtml;

  @override
  void initState() {
    super.initState();
    _articleHtml = _fetchArticleHtml(widget.article);
  }

  @override
  Widget build(BuildContext context) {
    final article = widget.article;
    return Scaffold(
      appBar: AppBar(
        leading: const BackButton(),
        backgroundColor: const Color(0xFF006B78),
        foregroundColor: Colors.white,
        centerTitle: true,
        title: const Text('Trang chủ'),
        actions: [
          IconButton(
            tooltip: 'Tải lại',
            onPressed: () => setState(() {
              _articleHtml = _fetchArticleHtml(article);
            }),
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 14, 18, 24),
        children: [
          Wrap(
            crossAxisAlignment: WrapCrossAlignment.center,
            spacing: 5,
            children: [
              const Text(
                'Trang chủ',
                style: TextStyle(fontSize: 14, color: Colors.black87),
              ),
              const Icon(Icons.chevron_right, size: 18, color: Colors.grey),
              Text(
                article.category,
                style: const TextStyle(fontSize: 14, color: Color(0xFF08747A)),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Text(
            article.title,
            style: const TextStyle(
              color: Color(0xFF006B78),
              fontSize: 27,
              fontWeight: FontWeight.w800,
              height: 1.28,
            ),
          ),
          if (article.publishedAt.isNotEmpty) ...[
            const SizedBox(height: 12),
            Text(
              article.publishedAt,
              style: const TextStyle(color: Color(0xFF888888), fontSize: 13),
            ),
          ],
          const SizedBox(height: 18),
          FutureBuilder<String>(
            future: _articleHtml,
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Padding(
                  padding: EdgeInsets.all(24),
                  child: Center(
                    child: CircularProgressIndicator(color: Color(0xFF006B78)),
                  ),
                );
              }
              if (snapshot.hasError) {
                return Text(
                  'Không tải được nội dung HTML: ${snapshot.error}',
                  style: const TextStyle(color: Colors.grey),
                );
              }
              return Html(
                data: snapshot.data ?? '',
                style: {
                  'body': Style(
                    margin: Margins.zero,
                    padding: HtmlPaddings.zero,
                    fontSize: FontSize(17),
                    lineHeight: const LineHeight(1.5),
                    color: const Color(0xFF171717),
                  ),
                  'p': Style(
                    textAlign: TextAlign.justify,
                    margin: Margins.only(bottom: 15),
                  ),
                  'em': Style(fontStyle: FontStyle.italic),
                  'i': Style(fontStyle: FontStyle.italic),
                  'a': Style(color: const Color(0xFF08747A)),
                },
              );
            },
          ),
        ],
      ),
      bottomNavigationBar: AppBottomNavigation(
        selectedIndex: 0,
        onSelected: (index) {
          widget.onTabSelected?.call(index);
          Navigator.of(context).pop();
        },
      ),
    );
  }
}

// ─── Error View ───────────────────────────────────────────────────────────────

class _ErrorView extends StatelessWidget {
  const _ErrorView({required this.message, required this.onRetry});

  final String message;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(
              Icons.wifi_off_rounded,
              size: 56,
              color: Color(0xFF006B78),
            ),
            const SizedBox(height: 16),
            const Text(
              'Không tải được tin tức',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 8),
            Text(
              message,
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 12, color: Colors.grey[600]),
            ),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF006B78),
                foregroundColor: Colors.white,
              ),
              onPressed: onRetry,
              icon: const Icon(Icons.refresh),
              label: const Text('Thử lại'),
            ),
          ],
        ),
      ),
    );
  }
}
